using System;
using System.Collections.Generic;

public class OneArmBandit {
  
  /*
  Jednoreki bandyta - czym jest? https://pl.wikipedia.org/wiki/Jednor%C4%99ki_bandyta 

  Napisz program, który w zależności ile gracz "monet" wrzuci, tyle razy zostanie uruchomiona maszyna - w podstawowej wersji gracz wygrywa tylko w sytuacji kiedy maszyna rozlosuje trzy takie same elementy, a przegrywa w pozostałych przypadkach. 

  Przed uruchomieniem maszyny program poprosi użytkownika o imię, liczbe wrzuconych monet a następnie uruchomi losowanie znaków - w zależności od liczby wrzuconych monet losowanie powtórzy się N razy (zostanie przerwane jeżeli w danym losowaniu znaki będą takie same, bądź skończą się "monety") - w obu wypadkach użytkownik zostanie powiadomiony o rezultacie końcowym 

  */

  /* 
  Z jakich "elementów" może składać się jednoręki bandyta? 

  Pomocne mogą okazać się listy, proste zmienne przechowywujące wartości liczbowe
  */



  /* 
  Z jakich zachowań? Metod? 

  Spróbuj każdy etap podzielić na osobną metode a następnie wywołać ją w metodzie run
  */


  public void RunMachine() {

  }

}