using System;

class MainClass {
  public static void Main (string[] args) {
    OneArmBandit machine = new OneArmBandit();

  string[] emote = {"🍇 ", "🍒 ", "🍐 ", "🍋 "};

  int sumOfCoinsInserted = 3;
  //Console.WriteLine("masz"+ sumOfCoinsInserted+ "monet. Ile chcesz dodać monet?")
  int obecna_tura = 1;
  while (obecna_tura <= sumOfCoinsInserted){

  obecna_tura++;
  Random random = new Random(); 

  int one = random.Next(3);
  int two = random.Next(3);
  int three = random.Next(3);
  
  Console.WriteLine("["+ emote[one] + "]"+"["+ emote[two] +"]"+"["+ emote[three] +"]");
    machine.RunMachine();
    if (emote[one]==emote[two]&&emote[one]==emote[three]){
      Console.WriteLine ("Brawo, wygrałeś!");
    }else{
      Console.WriteLine ("Przegrałeś");
    } 
    Console.ReadLine();
  }


  }
}